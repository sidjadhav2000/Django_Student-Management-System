from django import forms
from .models import StudentModel,  DeptModel

class DeptForm(forms.ModelForm):
	class Meta:
		model = DeptModel
		fields = "__all__"

class StudentForm(forms.ModelForm):
	class Meta:
		model = StudentModel
		fields = "__all__"
       