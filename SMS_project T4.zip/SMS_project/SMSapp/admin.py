from django.contrib import admin
from .models import *

admin.site.register(StudentModel)
admin.site.register(DeptModel)
# Register your models here.
